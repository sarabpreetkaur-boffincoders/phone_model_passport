import { Strategy} from "passport-local";
import user_record_model from "./api/v1/src/model/user_model";
import bcrypt from "bcrypt"
import {FacebookStrategy} from "passport-facebook"

export const strategy = (passport) =>
  passport.use(
    new Strategy({
      usernameField: 'email',
      passwordField: 'password',
      session: true
    },(async function (email, password, done) {
      
  await  user_record_model.findOne({email:email }, async function (err, user) {
    //console.log(user)
        if (err) {
          return done(err);
        }
        if (!user) {
          return done(null, false);
        }
        if(user)
       await bcrypt.compare(
      password,
      user.password
        );
        return done(null, user);
      });
    })
  ));
  export const facebook_strategy = (passport) =>
  passport.use(new FacebookStrategy({
    clientID: FACEBOOK_APP_ID,
    clientSecret: FACEBOOK_APP_SECRET,
    callbackURL: "http://localhost:3000/auth/facebook/callback"
  },
  function(accessToken, refreshToken, profile, cb) {
    user_record_model.findOrCreate({ facebookId: profile.id }, function (err, user) {
      return cb(err, user);
    });
  }
));